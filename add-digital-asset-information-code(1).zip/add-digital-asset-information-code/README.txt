DigiWill BD - Add Digital Asset Information (extracted source files)

These are the original files copied from the uploaded digiwill-bd.zip archive.
They are grouped by their role in the Add Digital Asset Information feature.

Frontend core:
- frontend/src/pages/Vault.jsx: asset list, add/edit form, details, document UI, nominee selection.
- frontend/src/lib/vault.js: load/save/delete assets, encrypted document upload/download, nominee assignment calls.
- frontend/src/lib/crypto.js: client-side encryption and decryption helpers.
- frontend/src/lib/categories.js: asset categories and default form data.
- frontend/src/lib/api.js: API request helper.
- frontend/src/context/VaultContext.jsx: unlocked vault key context.
- frontend/src/components/VaultGate.jsx and ui.jsx: vault gate and shared UI components.
- frontend/src/i18n/*: labels and messages used by the page.

Backend core:
- backend/vault/models.py: VaultKey, Asset and Document database models.
- backend/vault/serializers.py: request validation and API serialization.
- backend/vault/views.py: vault key, asset and document API logic.
- backend/vault/urls.py: API routes.
- backend/vault/migrations/0001_initial.py: initial database migration.
- backend/digiwill/fields.py: Base64 and IV serializer fields used by the vault serializers.
- backend/legacy/models.py and services.py: activity logging dependencies used by the vault views.

Note: This is a feature-focused extraction, not a standalone runnable project. It preserves the original source files and relative folder structure; the full project settings, package dependencies, authentication, nominee and assignment endpoints are outside this selection.
